#!/bin/bash -l

#SBATCH --nodes=1
#SBATCH --ntasks=32
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=8G
#SBATCH --time=2-00:00:00     # 2 days
#SBATCH --output=my.stdout.VEP
#SBATCH --mail-user=maierpa@gmail.com
#SBATCH --mail-type=ALL
#SBATCH --job-name="readrepresentation"
#SBATCH -p batch # This is the default partition, you can use any of the following; intel, batch, highmem, gpu

module unload perl/5.20.2
module load perl/5.22.0

cd /rhome/agottscho/bigdata/Paul/RNAseq/ensembl-vep

grep -v "#" yotoad.gff | sort -k1,1 -k4,4n -k5,5n -t$'\t' > yotoad1.gff;
sed -i '/^$/d' yotoad1.gff;
bgzip yotoad1.gff;
tabix -p gff yotoad1.gff.gz;
mv yotoad1.gff.gz yotoad.gff.gz;
mv yotoad1.gff.gz.tbi yotoad.gff.gz.tbi;

./vep -i genotyped.multiInterval.bisnps.edited.vcf -gff yotoad.gff.gz -fasta sequences.fa --vcf --vcf_info_field ANN
