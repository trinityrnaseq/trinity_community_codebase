# Import joint genotyping biallelic SNP VCF, merge with reference SNPs
suppressMessages(library(vcfR))
suppressMessages(library(plyr))
setwd("~/Desktop/genotyping/final_editing")
vcf.file <- read.vcfR("genotyped.multiInterval.bisnps.vcf", verbose = F)
snps <- read.table("SNPlistREFALT.txt", header=T, sep="\t", stringsAsFactors=F)
vcf <- data.frame(vcf.file@fix, stringsAsFactors=F)
vcf <- vcf[,c(1,2,4,5)]
snps <- snps[,c(1,2,4,5)]
names(snps)[3:4] <- c("REF.ref", "ALT.ref")
both <- join(vcf, snps, by=c("CHROM","POS"))

# Find any SNPs where REF or ALT do not agree across datasets
sum(both$REF == both$REF.ref) == nrow(vcf)
sum(both$ALT == both$ALT.ref) == nrow(vcf)
both[which(both$ALT != both$ALT.ref),]

# Remove these
vcf.file@fix <- vcf.file@fix[-which(both$ALT != both$ALT.ref),]
vcf.file@gt <- vcf.file@gt[-which(both$ALT != both$ALT.ref),]
both <- both[-which(both$ALT != both$ALT.ref),]

# Output edited joint genotyping VCF
write.vcf(vcf.file, file = "genotyped.multiInterval.bisnps.edited.vcf.gz")
system(paste0("gunzip ", "genotyped.multiInterval.bisnps.edited.vcf.gz"))
