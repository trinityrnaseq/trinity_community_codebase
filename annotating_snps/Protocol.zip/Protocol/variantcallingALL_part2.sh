#!/bin/bash -l

#SBATCH --nodes=1
#SBATCH --ntasks=32
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=8G
#SBATCH --time=2-00:00:00     # 2 days
#SBATCH --output=my.stdout.ALL
#SBATCH --mail-user=maierpa@gmail.com
#SBATCH --mail-type=ALL
#SBATCH --job-name="VariantCallingALL"
#SBATCH -p batch # This is the default partition, you can use any of the following; intel, batch, highmem, gpu

# Load modules
module load gatk/4.0.1.2

# Save variables for picard and gatk
export GATK_HOME=/opt/linux/centos/7.x/x86_64/pkgs/gatk/4.0.1.2/gatk
export fa_file=/rhome/agottscho/bigdata/Paul/RNAseq/trinity_genes.fasta
export threads=32

# Change directory to RNAseq directory, make output directory
cd /rhome/agottscho/bigdata/Paul/RNAseq/outputALL

# Variant Calling using Haplotype Caller.
$GATK_HOME --java-options "-Xmx8g" HaplotypeCaller  \
           -R $fa_file \
           -I splitNCigar.bam \
           -O output.all.vcf.gz \
           --dont-use-soft-clipped-bases true \
           -stand-call-conf 20.0 \
           -new-qual true \
           -ploidy 6 \
           --native-pair-hmm-threads $threads

# Doing some basic filtering of vcf.
$GATK_HOME VariantFiltration \
           -R $fa_file \
           -V output.all.vcf.gz \
           -window 35 \
           -cluster 3 \
           --filter-expression "FS > 30.0" \
           --filter-name "FS" \
           --filter-expression "QD < 2.0" \
           --filter-name "QD" \
           -O output.all.filtered.vcf.gz

# Unzip the vcf
gunzip output.all.filtered.vcf.gz

# Select biallelic SNPs only
$GATK_HOME SelectVariants \
           -R $fa_file \
           -V output.all.filtered.vcf \
           --select-type-to-include SNP \
           --restrict-alleles-to BIALLELIC \
           --exclude-filtered \
           -O output.all.filtered.bisnps.vcf


