#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=T)

VCF2multiInterval <- function(vcf.file, wd, snp.file) {
  # Assigns temporary chromosome the old chromosome labels
  # Assigns temporary positions the old position labels
  # Outputs restored vcf
  # Assumes vcf file is not gzipped
  
  #Force all integers to write as such, not scientific notation
  options(scipen=999)
  
  suppressMessages(library(vcfR))
  suppressMessages(library(plyr))
  
  # Get base name of vcf file (w/o .vcf)
  base.name <- gsub("(*).vcf", "\\1", vcf.file)
  
  # Import VCF file
  print("Reading VCF file.")
  setwd(wd)
  vcf <- read.vcfR(vcf.file, verbose = F)

  # Reorder to reference (ascending) SNP order
  print("Reordering SNPs to reference order. (Make sure ref SNPs are in ascending order.)")
  vcf@fix <- vcf@fix[order(as.integer(vcf@fix[,"POS"])),]
  vcf@gt <- vcf@gt[order(as.integer(vcf@fix[,"POS"])),]

  # Read in SNPs reference file
  print("Reading SNPs from reference file.")
  snps <- read.table(snp.file, header=T, sep="\t", stringsAsFactors=F)
  
  # Join to original SNP identity
  print("Renaming chromosomes and positions.")
  vcf.ID <- as.integer(vcf@fix[,"POS"])
  vcf@fix[,"CHROM"] <- snps[vcf.ID,"CHROM"]
  vcf@fix[,"POS"] <- snps[vcf.ID,"POS"]
 
  # Write out edited vcf file
  print("Writing edited VCF file.")
  vcf.file.edited <- paste0(base.name, ".multiInterval.vcf.gz")
  write.vcf(vcf, file = vcf.file.edited)
  system(paste0("gunzip ", vcf.file.edited))
  
  #Revert option
  options(scipen=0)
}

# Test if there are 3 arguments: if not, return an error
if (length(args) != 3) {
  stop("There should be 3 arguments.", call.=FALSE)
}

VCF2multiInterval(args[1], args[2], args[3])


